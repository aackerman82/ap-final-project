-- Lane Hayes
-- 4/16/2025
-- Applied Programming game project

function love.conf(t)
    t.window.width = 800
    t.window.height = 600
    t.window.title = "cavemap for game project"
end
