-- Lane Hayes
-- 4/16/2025
-- Applied Programming game project

sti = require "sti"

function love.load()
    tx = 0
    gameScreen = love.graphics.newCanvas(256*3,554)
    map = sti("Cave.lua")
end

function love.update(dt)
    if love.keyboard.isDown("a") then
        tx = tx + 1
    elseif love.keyboard.isDown("d") then
        tx = tx - 1
    end
    map:update(dt)
end

function love.draw()
    love.graphics.setCanvas(gameScreen) 
    love.graphics.clear()
    map:draw(tx)
    love.graphics.setCanvas()
    love.graphics.draw(gameScreen, 0, 0, 0, 2, 2)
    love.graphics.setColor(1, 1, 1)
    love.graphics.push()
    love.graphics.translate(tx, 0)
    love.graphics.pop()
end
